# Word Game

import random
import string

VOWELS = 'aeiou'
CONSONANTS = 'bcdfghjklmnpqrstvwxyz'
HAND_SIZE = 9

SCRABBLE_LETTER_VALUES = {
    'a': 1, 'b': 3, 'c': 3, 'd': 2, 'e': 1, 'f': 4, 'g': 2, 'h': 4, 'i': 1, 'j': 8, 'k': 5, 'l': 1, 'm': 3, 'n': 1, 'o': 1, 'p': 3, 'q': 10, 'r': 1, 's': 1, 't': 1, 'u': 1, 'v': 4, 'w': 4, 'x': 8, 'y': 4, 'z': 10
}


WORDLIST_FILENAME = "words.txt"

def loadWords():
    """
    Returns a list of valid words. Words are strings of lowercase letters.
    
    Depending on the size of the word list, this function may
    take a while to finish.
    """
    print("Loading word list from file...")
    inFile = open(WORDLIST_FILENAME, 'r')
    wordList = []
    for line in inFile:
        wordList.append(line.strip().lower())
    print("  ", len(wordList), "words loaded.")
    return wordList

def getFrequencyDict(sequence):
    """
    Returns a dictionary where the keys are elements of the sequence
    and the values are integer counts, for the number of times that
    an element is repeated in the sequence.

    sequence: string or list
    return: dictionary
    """
    freq = {}
    for x in sequence:
        freq[x] = freq.get(x,0) + 1
    return freq
	

def getWordScore(word, n):
    """
    Returns the score for a word.
    
    word: string (lowercase letters)
    n: integer (HAND_SIZE; i.e., hand size required for additional points)
    returns: int >= 0
    """
    word.lower()
    score=0
    for w in word:
        score+=SCRABBLE_LETTER_VALUES[w]
    score*=len(word)
    if len(word)==n:
        score+=50
    return score


def displayHand(hand):
    """
    Displays the letters currently in the hand.
    The order of the letters is unimportant.

    hand: dictionary (string -> int)
    """
    for letter in hand.keys():
        for j in range(hand[letter]):
             print(letter,end=" ")      
    print()                           

def dealHand(n):
    """
    Returns a random hand containing n lowercase letters.
    n/3 the letters in the hand are VOWELS.

    n: int >= 0
    returns: dictionary (string -> int)
    """
    hand={}
    numVowels = n // 3
    
    for i in range(numVowels):
        x = VOWELS[random.randrange(0,len(VOWELS))]
        hand[x] = hand.get(x, 0) + 1
        
    for i in range(numVowels, n):    
        x = CONSONANTS[random.randrange(0,len(CONSONANTS))]
        hand[x] = hand.get(x, 0) + 1
        
    return hand

#
# Problem #2: Update a hand by removing letters
#
def updateHand(hand, word):
    """
    Has no side effects: does not modify hand.

    word: string
    hand: dictionary (string -> int)    
    returns: dictionary (string -> int)
    """
    h=hand.copy()    
    for w in word:
        for i in h:
            if i==w and h[i]>0:
                h[i]-=1
    return h

def isValidWord(word, hand, wordList):
    """
    Returns True if word is in the wordList and is entirely
    composed of letters in the hand. Otherwise, returns False.
   
    word: string
    hand: dictionary (string -> int)
    wordList: list of lowercase strings
    """
    count=0
    h=hand.copy()
    for w in word:
        for i in h:
            if w==i and h[i]>0:
                count+=1
                h[i]-=1
    if count==len(word):
        return word in wordList
    else:
        return False

def calculateHandlen(hand):
    """ 
    Returns the length (number of letters) in the current hand.
    
    hand: dictionary (string-> int)
    returns: integer
    """
    sum=0
    for i in hand:
        sum+=hand[i]
    return sum
   


def playHand(hand, wordList, n):
    """
    Allows the user to play the given hand.

      hand: dictionary (string -> int)
      wordList: list of lowercase strings
      n: integer (HAND_SIZE; i.e., hand size required for additional points)
    """
    score=0
    while calculateHandlen(hand)>0:
        print("current hand: ",end='')
        displayHand(hand)
        word=input("Enter word, or a '.' to indicate that you are finished: ")
        if len(word)==1:
            if (word=='.'):
                print("game over! ",end='')
                break    
            else:
                print("invalid word!")
        else:
            if isValidWord(word,hand,wordList)==False:
                print("invalid word!")
            else:
                print('"'+word+'" earned '+str(getWordScore(word,n))+' points. ',end='')
                score+=(getWordScore(word,n))
                print("Total: "+str(score))
                hand=updateHand(hand, word)
                
    if (word=='.'):
        print("Total score: "+str(score))
    else:
        print("Run out of letters. Total score: "+str(score))
        
        
def playGame(wordList):
    """
    Allow the user to play an arbitrary number of hands.
    """
    prehand={}
    pn=0
    while True:
        inp=input("Enter n to deal a new hand, r to replay the last hand, or e to end game: ")
        if inp=='n':
            n=HAND_SIZE
            hand=dealHand(n)
            pn=n
            prehand=hand
            playHand(hand,wordList,n)
            
        elif inp=='r':
            if len(prehand)==0:
                print("You have not played a hand yet. Please play a new hand first!")
            else:
                playHand(prehand,wordList,pn)
                
        elif inp=='e':
            break
        else:
            print("invalid command.")
                     
            
if __name__ == '__main__':
    wordList = loadWords()
    playGame(wordList)
