from Project1 import *
import time


def compChooseWord(hand, wordList, n):
    """
    hand: dictionary (string -> int)
    wordList: list (string)
    n: integer (HAND_SIZE; i.e., hand size required for additional points)

    returns: string or None
    """
    bestScore = 0
    bestWord = None
    for word in wordList:
        if isValidWord(word, hand, wordList):
            score = getWordScore(word, n)
            if (score > bestScore):
                bestScore = score
                bestWord = word
    return bestWord


def compPlayHand(hand, wordList, n):
    """
    hand: dictionary (string -> int)
    wordList: list (string)
    n: integer (HAND_SIZE; i.e., hand size required for additional points)
    """
    totalScore = 0
    while (calculateHandlen(hand) > 0) :
        print("Current Hand: ", end=' ')
        displayHand(hand)
        word = compChooseWord(hand, wordList, n)
        if word == None:
            break
        else :
            if (not isValidWord(word, hand, wordList)) :
                print('This is a terrible error! I need to check my own code!')
                break
            else :
                score = getWordScore(word, n)
                totalScore += score
                print('"' + word + '" earned ' + str(score) + ' points. Total: ' + str(totalScore) + ' points')              
                hand = updateHand(hand, word)
                print()
    print('Total score: ' + str(totalScore) + ' points.')

    
def playGame(wordList):
    """
    wordList: list (string)
    """
    prehand={}
    pn=0
    while True:
        inp=input("Enter n to deal a new hand, r to replay the last hand, or e to end game: ")
        if inp=='n':
            n=HAND_SIZE
            hand=dealHand(n)
            pn=n
            prehand=hand
            inp1=''
            while inp1!='u' and inp1!='c':
                inp1=input("Enter u to have yourself play, c to have the computer play: ")
                if inp1=='u':
                    playHand(hand,wordList,n)
                elif inp1=='c':
                    compPlayHand(hand,wordList,n)
                else:
                    print("invalid command.")
            
        elif inp=='r':
            if len(prehand)==0:
                print("You have not played a hand yet. Please play a new hand first!")
            else:
                inp1=''
                while inp1!='u' and inp1!='c':
                    inp1=input("Enter u to have yourself play, c to have the computer play: ")
                    if inp1=='u':
                        playHand(prehand,wordList,pn)
                    elif inp1=='c':
                        compPlayHand(prehand,wordList,pn)
                    else:
                        print("invalid command.")
                
        elif inp=='e':
            break
        else:
            print("invalid command.")

        
if __name__ == '__main__':
    wordList = loadWords()
    playGame(wordList)


